package com.example.tuan6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tuan6Application {

	public static void main(String[] args) {
		SpringApplication.run(Tuan6Application.class, args);
	}

}
